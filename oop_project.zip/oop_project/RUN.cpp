#include"teacher_student.cpp"
class RUN:public teacher,public student
{
private:
    /* data */
public:
    RUN(/* args */)
    {
        cout<<"\ncreated run";
    }
    ~RUN()
    {
        cout<<"\ndestroy run";
    }
};

int main()
{
 RUN obl;
    return 0;
}
